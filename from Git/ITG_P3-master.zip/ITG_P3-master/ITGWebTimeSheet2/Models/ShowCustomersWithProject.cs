﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ITGWebTimeSheet2.Models
{
    public class ShowCustomersWithProject
    {
        public int custid { get; set; } 

        public string custcode { get; set; }
      
    }
}